in the appendix you will find 

1. The documentaton for the AS7341 ChipLib
2. Python package (Python version 3.5 and higher) as WHL for the AS7341 ChipLib
3. Release notes
4. Readme file for the Python package

The example shows a simple ChipLib usage via the wrapper.

The DLL binaries of the ChipLibs for sensor connection via FTDI adapter,
and via RPC to the Unicom Evalboard are included in the package.

The example shows the connection to a Unicom-Evalboard on COM10,

Your connection information would then have to be adjusted at "chiplib.initialize(...)".